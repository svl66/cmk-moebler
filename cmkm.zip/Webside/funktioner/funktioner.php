<?php
// Denne funktion sørger for, at man ikke kan skrive ren
// kode i inputfelter
function secInput($value){
    $value=trim($value);
    $value=htmlspecialchars($value);
    return $value;
}
// Denne funktion er en "not-empty-check". Tjekker om input rent faktisk
// har en værdi
function checkElement($value){
    $value=trim($value);
    if(isset($value[0])){
        return true;
    }else{
        return false;
    }
}
function showDate($date){
    
    // Jeg skal kun bruge dato til venstre for mellemrumstegn:
    // 2018-1-17 00:00:00
    // med explode kan jeg dele min streng op i 2:
    // $arr[0] = 2018-1-17 og $arr[1] = 00:00:00
    $arr=explode(" ",$date);
    $str = $arr[0];

    // Nu skal jeg finde de enkelte dato-elementer, og udskifte et tal
    // med en måned, samt at vise strengens elementer i den rigtige 
    // rækkefølge
    $str=explode("-", $str);
    
    return $str[2].' '.getMonth($str[1]).' '.$str[0];
}
function getMonth($value){
    switch ($value){
        case '01':
        $month='Januar';
        break;
        case '02':
        $month='Februar';
        break;
        case '03':
        $month='Marts';
        break;
        case '04':
        $month='April';
        break;
        case '05':
        $month='Maj';
        break;

        default:
        $month = 'Ukendt måned';
        break;
    }
    return $month;
}
function cutText($text){
    if(strlen($text) > 160){
        return substr($text, 0, 160).'...
        <p>&nbsp; &nbsp;<a class="orangeFont" href="#">Læs mere</a></p>';
    }else{
        return $text;
    }
}