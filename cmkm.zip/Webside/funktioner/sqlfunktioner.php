<?php
function getData($sql, $conn){
    $result = mysqli_query($conn, $sql);
    $antal = mysqli_num_rows($result);
    if($antal > 0){
        while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
            $arr[] = $row;
        }
    }else{
        $arr = null;
    }
    return $arr;
}
function insertData($sql, $conn, $name=[]){
    $result = mysqli_query($conn, $sql);
    if($result){
        if(is_array($name)){
            $lastId = mysqli_insert_id($conn);
            foreach($name as $value){
                $sql = "INSERT INTO `moebel_billede`(`FK_moebel`, `billednavn`) 
                VALUES ($lastId,'$value')";
                 mysqli_query($conn, $sql);
            }   
        } 
        return true;
    }else{
        return false;
    }
}