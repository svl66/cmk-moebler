<?php
$html = '
    <div class="myFunitureSection">
        <h5 class="orangeFont">Kontakt</h5>
        <p><strong>'.PROJECT_NAME.'</strong><br>
        Esplanaden 52 <br>
        2100 København K
        </p>
        <p><strong>Telefon</strong><br>3363 3363</p>
        <p><strong>Email</strong><br>'.PROJECT_EMAIL_SALES.'</p>
    </div>';
return $html;