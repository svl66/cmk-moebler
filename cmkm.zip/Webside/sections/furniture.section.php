<?php
$html = '
    <div class="myFunitureSection">
        <h5 class="orangeFont">Møbler</h5>';

// Min sql-sætning til hentning af data
$sql = 'SELECT moebler.pris, moebler.designaar, 
moebel_billede.billednavn,
designer.designnavn,
serie.serienavn
 FROM moebler
 INNER JOIN moebel_billede
 ON moebel_billede.FK_moebel = moebler.id
 INNER JOIN designer
 ON moebler.FK_designer = designer.id
 INNER JOIN serie
 ON moebler.FK_serie = serie.id
 ORDER BY rand() LIMIT 0,1';
 // Test:
//$html .= '<pre>'.print_r(getData($sql, $conn)).'</pre>';
// Nu har jeg data klar:
$dataArr = getData($sql, $conn);
foreach($dataArr as $key=>$data){
    $html .= '
            <p><img src="./images/'.$data['billednavn'].'" class="showImgFull" alt="'.$data['billednavn'].'"></p>
            <p><strong>Møbelserie</strong><br> '.$data['serienavn'].'</p>
            <p><strong>Designer</strong><br> '.$data['designnavn'].'</p>
            <p><strong>Designår</strong><br> '.$data['designaar'].'</p>
            <p><strong>Pris</strong><br> '.$data['pris'].'</p>
        ';
}
$html .= '</div>';
return $html;