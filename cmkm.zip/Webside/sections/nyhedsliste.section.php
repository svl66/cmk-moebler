<?php
// dette er vores sql-sætning vi sender afsted
// for at hent nyhederne
$sql = 'SELECT nyheder.*, bruger.navn 
FROM nyheder
INNER JOIN bruger
ON nyheder.FK_bruger = bruger.id
ORDER BY nyheder.id DESC';
// test
// echo '<pre>', print_r(getData($sql, $conn)), '</pre>'; 
$data = getData($sql, $conn);
$html = '';
foreach($data as $value){
    $html .= 
    '<div>
        <h3 class="orangeFont">'.$value['overskrift'].'</h3>
        <h5>af: <span class="orangeFont">'.$value['navn'].'</h5>
        <p> &#128336;
        '.showDate($value['oprettelsesdato']).'</p>
        <div>'.cutText($value['tekst']).'</div><hr>
    </div>';
}
return $html;