<?php
$html = '
    <script>
        function tjekForm(){
            var str=document.forms.formNyhedsbrev;
            if(str.email.value === "" || str.email.value.length < 6 ){
                alert(\'Email skal indholde mindst 6 tegn\');
                return false;
            }else if(str.email.value.indexOf("@") === -1 || str.email.value.indexOf(".") === -1){
                alert(\'Email SKAL indeholde et "@" og et "."\');
                return false;
            }
        }
    </script>
    <div class="myFunitureSection">
        <h5 class="orangeFont">Nyhedsbrev</h5>
        <form action="" method="post" id="formNyhedsbrev" onsubmit="return tjekForm()">
            <input type="text" name="email" id="email">
            <br>
            <div class="marginTop5">
                <input type="submit" class="btn btn-white" name="submitTilNyhedsbrev" value="✔ Tilmeld">
                <input type="submit" class="btn btn-white" name="submitFraNyhedsbrev" value="✖ Frameld">
            </div>
        </form>
    </div>';
return $html;