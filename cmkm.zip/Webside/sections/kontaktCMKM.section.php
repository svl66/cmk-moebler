<?php
$html = '
    <script>
        function tjekKontaktForm(){
            var str=document.forms.contactForm;
            if(str.navn.value === "" || str.navn.value.length <= 1 ){
                alert(\'Navn skal indholde mindst 2 tegn\');
                return false;
            }else if(str.adresse.value === "" || str.adresse.value.length <= 2 ){
                alert(\'Adresse skal indholde mindst 3 tegn\');
                return false;
           
            }else if(str.email.value.indexOf("@") === -1 || str.email.value.indexOf(".") === -1){
                alert(\'Email SKAL indeholde et "@" og et "."\');
                return false;
            
            }else if(str.telefon.value === "" || str.telefon.value.length !== 8 || isNaN(str.telefon.value) === true ){
                alert(\'Telefon skal indholde mindst 8 cirfre\');
                return false;

            }else if(str.kommentar.value.length < 15){
                alert(\'Du skal skrive en seriøs kommentar\');
                return false;
            }
        }
    </script>
    <div class="myFunitureSection">';
        if(isset($_SESSION['takForBesked'])){
            if($_SESSION['takForBesked'] === true){
                $html .= '<h3 class="orangeFont">
                    Tak for din henvendelse. Du vil høre fra os hurtigst muligt.</h3>';
                $_SESSION['takForBesked'] = false;
            }
       }

    $html .= '
        <h5 class="orangeFont">Åbningstider</h5>
        <p><strong>Mandag - Torsdag</strong><br>
        10.00-17.30
        </p>
        <p><strong>Fredag</strong><br>10.00-18.00</p>
        <p><strong>Lørdag</strong><br>10.00-14.00</p>
        
        <form class="form-inline" method="post" id="contactForm" onsubmit="return tjekKontaktForm()"><!--  -->
        
        <div class="form-group">
            <label for="navn" class="col-sm-2 control-label">Navn</label>
            <div class="col-sm-10">
            <input type="text" class="form-control" name="navn" id="navn" placeholder="Navn">
            </div>
        </div>
        <div class="form-group">
            <label for="adresse" class="col-sm-2 control-label">Adresse</label>
            <div class="col-sm-10">
            <input type="text" class="form-control" name="adresse" id="adresse" placeholder="Adresse">
            </div>
        </div>
        
        <div class="form-group">
            <label for="email" class="col-sm-2 control-label">Email</label>
            <div class="col-sm-10">
            <input type="email" class="form-control" name="email" id="email" placeholder="Email">
            </div>
        </div>
        <div class="form-group">
            <label for="telefon" class="col-sm-2 control-label">Telefon</label>
            <div class="col-sm-10">
            <input type="text" class="form-control" name="navn2" id="telefon" placeholder="Telefon">
            </div>
        </div>
        <div class="form-group">
            <label for="kommentar" class="col-sm-2 control-label">Kommentar</label>
            <div class="col-sm-10">
            <textarea placeholder="Kommentar" class="form-control" id="kommentar" name="kommentar"></textarea>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-12">
            <button type="submit" class="btn btn-success" name="submitKontakt">Send</button>
            </div>
        </div>
        </form>
        ';
return $html;