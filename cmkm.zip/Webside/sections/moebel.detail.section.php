<?php
$html = '
    <script>
        function showImg(imgSrc){
            document.getElementById(\'mainImage\').src = "./images/" + imgSrc;
        }
    </script>
    <div class="myFunitureSection">
        <div class="row">
            <div class="col-md-12">
                <img src="./images/'.$_GET['billednavn'].'" alt="" title="" class="showImgFull" id="mainImage">
            </div>
            <div class="col-md-12">
                <p><strong>'.$_GET['navn'].' '.$_GET['serie'].'</strong></p>
                <p>'.$_GET['tekst'].'</p>
            </div>
            <div class="col-md-12">
                <p><strong>Detaljer</strong></p>
                <ul>
                    <li>Designer: '.$_GET['designer'].'</li>
                    <li>Designår: '.$_GET['designaar'].'</li>
                    <li>Varenummer: '.$_GET['varnr'].'</li>
                    <li>Pris: '.$_GET['pris'].'</li>
                </ul>
            </div>
            <div class="col-md-12">
                <p>Varianter</p>';
                $id = $_GET['id'];
                $sql = "SELECT * FROM moebel_billede WHERE FK_moebel = ".$id;
                // hent de billeder der måtte være i tabellen 'moebel_billede'
                // knyttet til det pågældende produkt 
                $arr = getData($sql, $conn);
                if(is_array($arr)){
                    foreach($arr as $value){
                        $html .= '
                            <img onclick="showImg(\''.$value['billednavn'].'\');" class="visRamme" height="200" src="./images/thumbnails/'.$value['billednavn'].'" alt="" title="">
                        ';
                    }
                }
            $html .='    
            </div>            
        </div>
    </div>';
return $html;