<?php
$html = '
<script>
    function go2URL(url){
        window.location = url;
    }
</script>
';
if(isset($_POST['submitSearch'])){
    $html .= '<h3>Du søgte efter varenummeret: <span class="orangeFont">&quot;'.$_POST['varenummer'].'&quot;</span></h3>';
    $term = $_POST['varenummer'];
    $sql = "SELECT moebler.* FROM moebler WHERE varenummer LIKE '%".$term."%'";
    $arr = getData($sql, $conn);
    if(is_array($arr)){
        foreach($arr as $value){
            $html .= '<p>'.$value['navn'].'</p>';
        }
    }else{
        $html .= '<p class="orangeFont">Der er desværre ikke nogen emner der matcher dine kriterier. Vi anbefaler at du udvider din søgning og prøver igen.</p>';
    }
}
if(isset($_POST['submitSearchAdvanced'])){
    $sql ="SELECT DISTINCT moebler.*, moebel_billede.billednavn, 
        serie.serienavn, designer.designnavn FROM moebler
        INNER JOIN moebel_billede
        ON moebel_billede.FK_moebel = moebler.id
        INNER JOIN serie
        ON moebler.FK_serie = serie.id 
        INNER JOIN designer
        ON moebler.FK_designer = designer.id ";
        $sql .= "WHERE ((1=2) ";
    if(isset($_POST['serie'])){

        $arr = $_POST['serie'];
        foreach($arr as $value){
            $sql .= " OR  FK_serie = $value ";
        }
        
    }else{
        $sql .= '';
    }
    $sql .= ' ) AND ( (1=2) ';
    $arr = $_POST['designer'];
    foreach($arr as $value){
        if($value === "0"){
            // "alle" er valgt. Hent alle designere fra tabellen,
            // og loop igennem arrayet
            $sqlStr = "SELECT * FROM designer";
            $darr = getData($sqlStr, $conn);
            
            foreach ($darr as $key => $dvalue){
                $sql .= " OR  FK_designer = ".$dvalue['id']." ";
            }
        }else{
            $sql .= " OR  FK_designer = $value ";
        }    
    }
    $sql .= ") AND ((1=1) ";
    if(isset($_POST['designFromYear']) && isset($_POST['designToYear']) && ($_POST['designFromYear'] < $_POST['designToYear'])){
        $sql .= "AND (designaar BETWEEN ".$_POST['designFromYear']." AND ".$_POST['designToYear'].")";
    }
    $sql .= ") AND ((1=1) ";
    if(isset($_POST['prisMin']) && isset($_POST['prisMax']) && ($_POST['prisMin'] < $_POST['prisMax'])){
        $sql .= "AND (pris BETWEEN ".$_POST['prisMin']." AND ".$_POST['prisMax'].")";
    }
    $sql .= ") GROUP BY moebler.id";

    // Hent alle poster med getData() funktionen
    $arr=getData($sql, $conn);
    if(is_array($arr)){
        $_SESSION['visForm'] = false;
        foreach($arr as $value){
            $urlDetail = '?page=moebelDetail&id='.$value['id'].'&billednavn='.$value['billednavn'];
            $urlDetail .= '&navn='.$value['navn'].'&tekst='.rawurlencode($value['beskrivelse']);
            $urlDetail .= '&serie='.$value['serienavn'].'&designer='.$value['designnavn'];
            $urlDetail .= '&designaar='.$value['designaar'].'&varnr='.$value['varenummer'];
            $urlDetail .= '&pris='.$value['pris'];
            $html .= '
            <div class="row visRamme" onclick="go2URL(\''.$urlDetail.'\');">
                <div class="col-md-6">
                    <img src="./images/'.$value['billednavn'].'" alt="FOTO" title="Foto: '.$value['navn'].'" class="showImgFull">
                </div>
                <div class="col-md-6">
                    <p class="orangeFont">'.$value['navn'].'</p>
                    <p>'.substr($value['beskrivelse'], 0, 50).' ...</p>
                </div>    
            </div>';
        }
    }else{
        $html .= '<p class="orangeFont">Der er desværre ikke nogen emner der matcher dine kriterier. Vi anbefaler at du udvider din søgning og prøver igen.</p>'; 
    }   
}

if(isset($_SESSION['visForm'])){
    if($_SESSION['visForm'] === false){
        $html .= '<p><i>Søgeresultater</i></p>';    
    }
    unset($_SESSION['visForm']);
}else{
    $html .= '
    <div class="myFunitureSection">
        <form class="form-inline" method="post">
            <label class="sr-only" for="varenummer">Vare nr.</label>
            <input type="text" class="form-control mb-2 mr-sm-2 mb-sm-0" name="varenummer" id="varenummer" placeholder="Varenummer">

            <button type="submit" name="submitSearch" class="btn">Søg</button>
        </form>
        <hr>';
        $html .= '
        <form class="" method="post">
        <div>Møbelserie</div>';
            $sql = "SELECT * FROM serie";
            $arr = getData($sql, $conn);
            $checked = '';
            foreach($arr as $value){
                if(isset($_POST['serie'])){
                    if(in_array($value['id'], $_POST['serie'])){
                        $html .= '   
                        <div class="col-md-2 pull-left">
                            <div class="form-check">
                                <input checked name="serie[]" class="form-check-input" type="checkbox" value="'.$value['id'].'" id="check_'.$value['id'].'">
                                <label class="form-check-label" for="check_'.$value['id'].'">
                                    '.$value['serienavn'].'
                                </label>
                            </div>
                        </div>';
                    }else{
                        $html .= '   
                        <div class="col-md-2 pull-left">
                            <div class="form-check">
                                <input name="serie[]" class="form-check-input" type="checkbox" value="'.$value['id'].'" id="check_'.$value['id'].'">
                                <label class="form-check-label" for="check_'.$value['id'].'">
                                    '.$value['serienavn'].'
                                </label>
                            </div>
                        </div>';
                    }
                }else{
                    $html .= '   
                    <div class="col-md-2 pull-left">
                        <div class="form-check">
                            <input name="serie[]" class="form-check-input" type="checkbox" value="'.$value['id'].'" id="check_'.$value['id'].'">
                            <label class="form-check-label" for="check_'.$value['id'].'">
                                '.$value['serienavn'].'
                            </label>
                        </div>
                    </div>';
                }
            }
        $html .='
        <hr>
        <div>Designer</div>
        <select name="designer[]">
        <option class="dropdown-item" value="0">Alle</option>
        ';
        $sql = "SELECT * FROM designer";
        $arr = getData($sql, $conn);
        foreach($arr as $value){
            $designer = (isset($_POST['designer']))?($_POST['designer'][0]):('');
            if($value['id'] == $designer){
                $selected = 'selected';
            }else{
                $selected = '';
            }
            $html .= '
           <option '.$selected.' class="dropdown-item" value="'.$value['id'].'">'.$value['designnavn'].'</option>';
        }
        $designFromYear = (isset($_POST['designFromYear']))?($_POST['designFromYear']):('');
        $designToYear = (isset($_POST['designToYear']))?($_POST['designToYear']):('');
        $prisMin = (isset($_POST['prisMin']))?($_POST['prisMin']):('');
        $prisMax = (isset($_POST['prisMax']))?($_POST['prisMax']):('');
        
        $html .=' 
        </select>
        <hr>
        <div>Design-år</div>
        <input type="number" name="designFromYear" value="'.$designFromYear.'" placeholder="Min">
        <input type="number" name="designToYear" value="'.$designToYear.'" placeholder="Max">
        <hr>
        <div>Pris</div>
        <input type="number" name="prisMin" value="'.$prisMin.'" placeholder="Min">
        <input type="number" name="prisMax" value="'.$prisMax.'" placeholder="Max">
            <button type="submit" name="submitSearchAdvanced" class="btn">Søg</button>
        </form>
    </div>
    ';
}
return $html;