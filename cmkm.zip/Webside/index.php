<?php
require_once './config.inc.php';
require_once './conn.php';
require_once './funktioner/sqlfunktioner.php';
require_once './funktioner/funktioner.php';
//########################################################
// Dette område er reserveret til håndtering af data
// sendt af en bruger på sitet.

// Er der sendt data fra en formular med metoden 'post'?
if($_POST){
  // Fra hvilken formular?
  // Tilmeld?
  if(isset($_POST['submitTilNyhedsbrev'])){
    $email = $_POST['email'];
    $sql = "INSERT INTO nyhedsbrev (email, oprettelsesdato) VALUES ('$email', Now())";
    mysqli_query($conn, $sql);
    
  // Frameld?
  }else if(isset($_POST['submitFraNyhedsbrev'])){
    $email = $_POST['email'];
    $sql = "DELETE FROM nyhedsbrev WHERE email='$email'"; // <-- husk enkeltplinger!
    mysqli_query($conn, $sql);
  
  // Kontaktformularen?
  }else if(isset($_POST['submitKontakt'])){
    $navn = $_POST['navn'];
    $adresse = $_POST['adresse'];
    $telefon = $_POST['navn2'];
    $email = $_POST['email'];
    $kommentar = $_POST['kommentar'];
    
    // send email
    //$sendMail = mail(PROJECT_EMAIL_SALES, 'Kommentar fra: '.$navn.' ('.$email.')', $kommentar.' '.$telefon);
    $sendMail = true;
    if($sendMail){
      $_SESSION['takForBesked'] = true;
      header('location:?page=kontaktCMKM');
      exit();
    }
  }
}
//########################################################
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="./favicon.ico">

    <title><?php echo PROJECT_NAME; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="./css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <style>
        body {
            padding-top: 5rem;
        }
        .showImgFull { width: 100%; height:auto;}
        .mySpace {
            padding:0 3rem 0 1.5rem;
        }
        .bg-black{
            background-color:#222 !important;
        }
        .brandColor{
            color:#9d9d9d !important;
        }
        .brandColor:hover{
            color:#ff7200 !important;
        }
        .orangeFont{ color: #ff7200}
        .myFurnitureInfo{background-color:#f5f5f5 !important; border: 2px solid #e3e3e3; border-radius:5px;}
        .myFunitureSection{padding:5px;}
        .margin5{margin:5px}
        .marginTop5{margin-top:5px}
        .btn-white{background-color:#ffffff !important; border: 2px solid #e3e3e3; border-radius:5px;}
        .myContactLabel {background-color:#eeeeee !important;}
        .visRamme{border:1px solid transparent}
        .visRamme:hover{border:1px solid #eee; cursor:pointer}
        .myNewNav {max-width: 1280px; margin:auto;} /* til senere (?) */
    </style>
  </head>

  <body>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-black">
      <a class="navbar-brand brandColor" href="index.php"><?php echo PROJECT_NAME; ?></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsDefault">
        <ul class="nav navbar-nav ml-auto ">
          <li class="nav-item">
            <a class="nav-link" href="?page=nyhedsarkiv">Nyhedsarkiv<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="?page=moebler">Møbler</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="?page=kontaktCMKM">Kontakt</a>
          </li>
          <!--
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <a class="dropdown-item" href="#">Something else here</a>
            </div>
          </li>
          -->
        </ul>
        <!--
        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
        -->
      </div>
    </nav>
    <header>
    <!-- logo mm. -->
    </header>
    <main role="main" class="container mySpace">
      <div class="row">
        <div class="col-md-12">
          <h1><?php echo PROJECT_NAME; ?></h1><hr>
        </div>
      </div>
      <div class="row">
          <div class="col-md-4">
            <div class="myFurnitureInfo">
              <?php 
              include_once './sections/furniture.section.php'; 
              echo $html;
              ?>
            </div>
            <p>&nbsp;</p>
            <div class="myFurnitureInfo">
              <?php 
              include_once './sections/nyhedsbrev.section.php'; 
              echo $html;
              ?>
            </div>
            <p>&nbsp;</p>
            <div class="myFurnitureInfo">
              <?php 
              include_once './sections/kontakt.section.php'; 
              echo $html;
              ?>
            </div>
          </div>
          <div class="col-md-8">
          <div>
              <?php
              if($_GET){
                if(isset($_GET['page'])){
                  switch ($_GET['page']){
                    case 'nyhedsarkiv':
                    include_once './sections/nyhedsarkiv.section.php';
                    break;
                    
                    case 'moebler':
                    include_once './sections/moebler.section.php';
                    break;

                    case 'moebelDetail':
                    include_once './sections/moebel.detail.section.php';
                    break;

                    case 'kontaktCMKM':
                    include_once './sections/kontaktCMKM.section.php';
                    break;

                    default:
                    echo 'Der opstod en fejl :)';
                    break;
                  }
                }
              }else{
                include_once './sections/nyhedsliste.section.php'; 
              }
              echo $html;
              ?>
            </div>
          </div>
      </div>
      <footer>
        <hr>
        <p>CMK Møbler / Terminsprøve | <a href="./admin/index.php" title="Midlertidigt link admin">Admin</a></p>
      </footer>
    </main><!-- /.container -->
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
    <script src="./js/bootstrap.min.js"></script>
  </body>
</html>