-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 27, 2018 at 12:13 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rts_cmkm`
--

-- --------------------------------------------------------

--
-- Table structure for table `bruger`
--

CREATE TABLE `bruger` (
  `id` int(11) NOT NULL,
  `navn` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `FK_rolle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bruger`
--

INSERT INTO `bruger` (`id`, `navn`, `email`, `password`, `FK_rolle`) VALUES
(1, 'Admin', 'admin@admin.dk', '1234', 1),
(2, 'Bent Bruger', 'bent@bruger.dk', '1234', 2);

-- --------------------------------------------------------

--
-- Table structure for table `designer`
--

CREATE TABLE `designer` (
  `id` int(11) NOT NULL,
  `designnavn` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `designer`
--

INSERT INTO `designer` (`id`, `designnavn`) VALUES
(1, 'Karl Rüdiger'),
(2, 'Hans J. Wegner'),
(3, 'Bruno Mathsson'),
(4, 'Morten Voss'),
(5, 'Kasper Salto'),
(6, 'Willam Du Ville');

-- --------------------------------------------------------

--
-- Table structure for table `moebel_billede`
--

CREATE TABLE `moebel_billede` (
  `FK_moebel` int(11) NOT NULL,
  `billednavn` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `moebel_billede`
--

INSERT INTO `moebel_billede` (`FK_moebel`, `billednavn`) VALUES
(5, 'bari_boe.jpg'),
(5, 'bari_eg.jpg'),
(5, 'bari_valnut.jpg'),
(34, 'be3e79688668846412b5fa889de4f786_frontPicture_5.jpg'),
(34, 'be3e79688668846412b5fa889de4f786_frontPicture_9.jpg'),
(34, 'be3e79688668846412b5fa889de4f786_giphy.gif'),
(2, 'brisbane_grey.jpg'),
(2, 'brisbane_rod.jpg'),
(2, 'brisbane_sort.jpg'),
(4, 'fedtmule.jpg'),
(1, 'less_grey.jpg'),
(1, 'less_rod.jpg'),
(1, 'less_sort.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `moebler`
--

CREATE TABLE `moebler` (
  `id` int(11) NOT NULL,
  `varenummer` varchar(255) NOT NULL,
  `navn` varchar(150) NOT NULL,
  `beskrivelse` text NOT NULL,
  `pris` decimal(18,2) NOT NULL,
  `FK_designer` int(11) NOT NULL,
  `FK_serie` int(11) NOT NULL,
  `designaar` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `moebler`
--

INSERT INTO `moebler` (`id`, `varenummer`, `navn`, `beskrivelse`, `pris`, `FK_designer`, `FK_serie`, `designaar`) VALUES
(1, '123456', 'Less', 'Less er det seneste bud på en danskproduceret kvalitetssofa, der repræsenterer det bedste i CMK møblers designfilosofi. Gennemført kvalitet til menneskelige priser. Det er eget design helt fra bunden med en kerne i massivt træ og polstring i det bedste skum. Derfor er der også 7 års garanti mod deformation på puderne. Ben i rustfrit stål.', '4470.00', 1, 1, 2004),
(2, '132456', 'Brisbane', 'Brisbane-serien har et stramt, stilsikkert formsprog, der fuldendes af et elegant chromstel. Vælg mellem to eksklusive læderkvaliteter og en blød stofudgave – alle i mange spændende farvevarianter. ', '5765.00', 1, 5, 2005),
(3, '241345', 'Bari', 'Bari bordet er ægte dansk håndværk af massiv amerikansk ege- eller valnøddetræ.\r\nStellet er i  Rustfrit stål. Bordet leveres incl. Olieplejesæt', '2999.00', 2, 2, 2004),
(4, '67rt8tkgotg', 'Fedtmule', 'Fedtmule er en spisestol i naturgummi der fås i mange faver.', '3000.00', 5, 3, 1967),
(5, '241345', 'Bari', 'Bari bordet er ægte dansk håndværk af massiv amerikansk ege- eller valnøddetræ. Stellet er i Rustfrit stål. Bordet leveres incl. Olieplejesæt', '2999.00', 2, 2, 2004),
(34, '10101010', 'Aarhus', 'Et gummimøbel', '10.00', 6, 5, 1966);

-- --------------------------------------------------------

--
-- Table structure for table `nyheder`
--

CREATE TABLE `nyheder` (
  `id` int(11) NOT NULL,
  `overskrift` varchar(50) NOT NULL,
  `tekst` text NOT NULL,
  `oprettelsesdato` datetime NOT NULL,
  `FK_bruger` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nyheder`
--

INSERT INTO `nyheder` (`id`, `overskrift`, `tekst`, `oprettelsesdato`, `FK_bruger`) VALUES
(1, 'Det er onsdag i dag', 'I dag er det onsdag, og vi bygger database med funktioner, som så skal gengruges.', '2018-01-17 00:00:00', 1),
(2, 'Funktioner', 'Der er brug for mange funktioner i dette projekt. Vi har valgt procedural :)', '2018-01-17 00:00:00', 2),
(3, 'Vinterferie', 'Københavnerne får ikke vinterferie i år. De startede nemlig en uge senere end alle andre på holdet, og skal derfor i skole i uge 8. Der skal vi kode et projekt i PHP.', '2018-01-17 05:24:25', 1),
(4, 'En salatskål - er ikke bare en salatskål...', 'Nej, en salatskål fra det århusianske firma Ego skal være både flot, fræk og ikke mindst funktionel. Fx med en forhøjning i midten, hvor salatbestikket kan hvile, mener direktør i Ego, Michael Bruun, og designer Steffen Schmelling. Sammen står de bag en række lækre produkter til køkken og spisebord. \r\n\r\n- Vores design er lidt en reaktion på noget, der har været meget af, nmelig \"holderen til holderen\" - design for designets skyld. Det skal være super funktionelt og samtidig noget der overrasker brugeren, mener Michael Bruun. Både indkøbere og kunder har taget overmåde godt imod produkterne, som også møder succes internationalt, og de vil være at finde i butikkerne fra juni 2016.', '2018-01-19 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `nyhedsbrev`
--

CREATE TABLE `nyhedsbrev` (
  `id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `oprettelsesdato` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nyhedsbrev`
--

INSERT INTO `nyhedsbrev` (`id`, `email`, `oprettelsesdato`) VALUES
(1, 'dfghjklæøhjkl', '2018-01-19 10:49:32'),
(7, '', '2018-01-19 12:07:37'),
(8, 'ghjknm', '2018-01-19 12:12:29'),
(10, 'cvbnm', '2018-01-19 12:14:20'),
(11, '12345@', '2018-01-19 12:23:20'),
(12, '1234@', '2018-01-19 12:23:27'),
(13, 'a@1.dk', '2018-01-19 12:24:36'),
(14, 'andersand@andeby.dk', '2018-01-19 12:29:13');

-- --------------------------------------------------------

--
-- Table structure for table `rolle`
--

CREATE TABLE `rolle` (
  `id` int(11) NOT NULL,
  `rollenavn` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rolle`
--

INSERT INTO `rolle` (`id`, `rollenavn`) VALUES
(1, 'administrator'),
(2, 'medarbejder');

-- --------------------------------------------------------

--
-- Table structure for table `serie`
--

CREATE TABLE `serie` (
  `id` int(11) NOT NULL,
  `serienavn` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `serie`
--

INSERT INTO `serie` (`id`, `serienavn`) VALUES
(1, 'Sofa'),
(2, 'Sofabord'),
(3, 'Spisestol'),
(4, 'Spisebord'),
(5, 'Gummimøbler'),
(6, 'Bomuldsmøbler');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bruger`
--
ALTER TABLE `bruger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `designer`
--
ALTER TABLE `designer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `moebel_billede`
--
ALTER TABLE `moebel_billede`
  ADD PRIMARY KEY (`billednavn`);

--
-- Indexes for table `moebler`
--
ALTER TABLE `moebler`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nyheder`
--
ALTER TABLE `nyheder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nyhedsbrev`
--
ALTER TABLE `nyhedsbrev`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `rolle`
--
ALTER TABLE `rolle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `serie`
--
ALTER TABLE `serie`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bruger`
--
ALTER TABLE `bruger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `designer`
--
ALTER TABLE `designer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `moebler`
--
ALTER TABLE `moebler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `nyheder`
--
ALTER TABLE `nyheder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `nyhedsbrev`
--
ALTER TABLE `nyhedsbrev`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `rolle`
--
ALTER TABLE `rolle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `serie`
--
ALTER TABLE `serie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
