<?php
$html = '';
if($_POST){
    if(isset($_POST['submitNySerie'])){
        $serienavn = secInput($_POST['serie']);
        if( checkElement($serienavn)){
            $sql = "INSERT INTO `serie`(`serienavn`) VALUES ('$serienavn')";
            insertData($sql, $conn);
            $html .= '<p class="orangeFont">Du har indsat ny serie ('.$serienavn.') med succes!';
        }
    }
}
$html .= '
    <script>
        function tjekForm(){
            var str=document.forms.formSerie;
            if(str.serie.value === ""){
                alert(\'Serie skal indholde et ord\');
                return false;
            }
        }
    </script>
    <div class="myFunitureSection">
        <h5 class="orangeFont">Opret ny serie</h5>
        <form action="" method="post" id="formSerie" onsubmit="return tjekForm()">
            <input type="text" name="serie" id="serie">
            <br>
            <div class="marginTop5">
                <input type="submit" class="btn btn-white" name="submitNySerie" value="Tilføj">
            </div>
        </form>
    </div>';
return $html;