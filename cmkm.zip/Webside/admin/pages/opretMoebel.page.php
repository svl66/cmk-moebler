<?php
$html = '';
if($_POST){
    if(isset($_POST['submitIndsaetMoebel'])){
        // tester for foto! Foto SKAL være med!
        
        if (isset($_FILES['produktfoto'])) {
            $myFile = $_FILES['produktfoto'];       // her er info vi skal bruge
            $fileCount = count($myFile["name"]);    // antal filer
            $target='../images/';                   // "Original-filer"
            $targetThumb='../images/thumbnails/';   // Små filer
            
            for ($i = 0; $i < $fileCount; $i++) {
                
                $img = $myFile["tmp_name"][$i];                                 // Selve "filen"
                $imgName = md5(date('Y-m-d H:i:s')).'_'.$myFile["name"][$i];    // Navnet på filen
                $imgType = $myFile["type"][$i];                                 // Typen på filen
                
                $namesToDb[] = $imgName;

                if($imgType === 'image/jpeg' || $imgType === 'image/gif' || $imgType === 'image/png'){
                    move_uploaded_file($img, $target."/".$imgName);
                    $size = getimagesize($target."/".$imgName);
                    if($size[0] > 0){
                        // udregn størrelsesforhold, længde - bredde forhold. (ratio)
                        $widthOrg=$size[0];
                        $heightOrg=$size[1];
                        if ( ($widthOrg > 0) && ($heightOrg > 0) ){
                            $ratioOrg = $widthOrg/$heightOrg;
                        }else{
                            return false;
                        }
                        $newWidth = 300;
			            $newHeight = 200;
			
                        if ($newWidth/$newHeight > $ratioOrg) {   // Højformat
                            $newWidth = $newHeight*$ratioOrg;
                        }else{
                            $newHeight = $newWidth/$ratioOrg;     // bredformat
                        }

                        switch ($imgType){
                            case 'image/png':
                                $image_new = imagecreatetruecolor($newWidth, $newHeight); // 
                                if($image = imagecreatefrompng($target."/".$imgName)){
                                    imagecopyresampled($image_new, $image, 0, 0, 0, 0, $newWidth, $newHeight, $widthOrg, $heightOrg);
                                    imagepng($image_new, $targetThumb.$imgName); // Gemmer billedet 
                                }
                            break;
                            
                            case 'image/gif':
                            $image_new = imagecreatetruecolor($newWidth, $newHeight); // 
                            if($image = imagecreatefromgif($target."/".$imgName)){
                                imagecopyresampled($image_new, $image, 0, 0, 0, 0, $newWidth, $newHeight, $widthOrg, $heightOrg);
                                imagegif($image_new, $targetThumb.$imgName); // Gemmer billedet 
                            }
                            break;

                            case 'image/jpeg':
                            $image_new = imagecreatetruecolor($newWidth, $newHeight); // 
                                if($image = imagecreatefromjpeg($target."/".$imgName))
                                {
                                    imagecopyresampled($image_new, $image, 0, 0, 0, 0, $newWidth, $newHeight, $widthOrg, $heightOrg);
                                    imagejpeg($image_new, $targetThumb.$imgName); // Gemmer billedet 
                                }
                            break;

                            default:
                            break;
                        }

                    }else{
                        // Hvis filen ikke er et billede, kan højde ikke beregnes,
                        // og filen slettes!
                        unlink($target."/".$imgName);
                    }
                }
            }
        }
        //echo '<pre>',print_r($namesToDb),'</pre>';
        /*
        exit;
        $target = '../images';
        $mineFiler=$_FILES['produktfoto'];   
        // Vi gemmer alle filerne i et array, med en integer ($i) som nøgle
        $i=0;
        foreach($mineFiler['tmp_name'] AS $key=>$value){
            $tmp_name[$i]=$value;
            $i++;
        }
        
        // Vi gemmer alle NAVNENE på filerne i et array, også med en integer ($i) som nøgle
        $i=0;
        foreach($mineFiler['name'] AS $key=>$value){
            $name[$i]=md5(date('D, d M Y H:i:s')).'_'. $value;
            $i++;
        }
        //exit(print_r($name));
        // hvor mange gange skal vi køre "move_uploaded_file" - løkken?
        $max=count($name);
        for($i=0; $i<$max; $i++){
            // Flyt billedet
            move_uploaded_file($tmp_name[$i], $target."/".$name[$i]);

            // "Byg" et nyt billede ved hjælp af PHP
            $size = getimagesize($target."/".$name[$i]);
            $width_orig = $size[0];
            $height_orig = $size[1];

            // Tester filens endelse
            $fillaengde=strlen($name[$i]);
			$pos=$fillaengde-4;
            $extension=substr($name[$i],$pos,4);
            //exit('Filtype: '.$extension); // (test)
            if ($extension == '.jpg' || $extension == 'jpeg'){
                $newWidth  = ($width_orig/10);
                $newHeight = ($height_orig/10);
                $image_new = imagecreatetruecolor($newWidth, $newHeight); // 
                if($image = imagecreatefromjpeg($target."/".$name[$i]))
                {
                    imagecopyresampled($image_new, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width_orig, $height_orig);
                    imagejpeg($image_new, "../images/thumbnails/".$name[$i]); // Gemmer billedet 
                }
            }else if ($extension == '.png'){
                $newWidth  = ($width_orig/5);
                $newHeight = ($height_orig/5);
                $image_new = imagecreatetruecolor($newWidth, $newHeight); // 
                if($image = imagecreatefrompng($target."/".$name[$i]))
                {
                    imagecopyresampled($image_new, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width_orig, $height_orig);
                    imagepng($image_new, "../images/thumbnails/".$name[$i]); // Gemmer billedet 
                }
            }else if($extension == '.gif'){
                $newWidth  = ($width_orig/5);
                $newHeight = ($height_orig/5);
                $image_new = imagecreatetruecolor($newWidth, $newHeight); // 
                if($image = imagecreatefromgif($target."/".$name[$i]))
                {
                    imagecopyresampled($image_new, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width_orig, $height_orig);
                    imagegif($image_new, "../images/thumbnails/".$name[$i]); // Gemmer billedet 
                }        
            }
        }
        */
        /// Hvis du kun skal uploade ét billede ad gangen, så brug denne SIMPLE:
        /*
        $foto = $_FILES['produktfoto'];
        if($foto['size'] > 0 ){
            $fotonavn =  $foto['name'];
            $fotofil =  $foto['tmp_name'];
            $target = '../images/'.$fotonavn;
            move_uploaded_file($fotofil, $target);
        }else{
            $fotonavn ='';
        }
        */

        $moebelnavn = secInput($_POST['moebelnavn']);
        $varenummer = secInput($_POST['varnr']);
        $beskrivelse = secInput($_POST['beskrivelse']);
        $serie = (isset($_POST['serie']))?(secInput($_POST['serie'])):('');
        $designer = secInput($_POST['designer']);
        $designAar = secInput($_POST['designAar']);
        $pris = secInput($_POST['pris']);

        $sql = "INSERT INTO `moebler`(`varenummer`, `navn`, `beskrivelse`, `pris`, `FK_designer`, `FK_serie`, `designaar`) 
        VALUES ('$varenummer','$moebelnavn','$beskrivelse', $pris, $designer, $serie, $designAar)";
        
        if(checkElement($moebelnavn) && checkElement($varenummer) && checkElement($beskrivelse)
            && checkElement($serie) && checkElement($designer) && checkElement($designAar)
            && checkElement($pris)){
                if(insertData($sql, $conn, $namesToDb)){
                    $html = '<p class="orangeFont">Du har indsat et møbel med succes!</p>';
                }
                
        }else{
            $html = '<p class="orangeFont">Der opstod en fejl</p>';
        }
        
    }
}
$html .= '
    <div class="row">
        <div class="col-md-12">
            <h2>Opret Møbel</h2>
            <form class="" method="post" enctype="multipart/form-data">
        <div>Møbelnavn</div>
        <input type="text" name="moebelnavn" placeholder="Møbelnavn">
        <hr>
        <div>Varenummer</div>
        <input type="text" name="varnr" placeholder="Varenummer">
        <hr>
        <div>Beskrivelse</div>
        <textarea name="beskrivelse" placeholder="Beskrivelse"></textarea>
        <hr>
        <div>Møbelserie</div>';
            $sql = "SELECT * FROM serie";
            $arr = getData($sql, $conn);
            $checked = '';
            foreach($arr as $value){
                $html .= '   
                <div class="col-md-2 pull-left">
                    <div class="form-radio">
                        <input name="serie" class="form-check-input" type="radio" value="'.$value['id'].'" id="check_'.$value['id'].'">
                        <label class="form-check-label" for="check_'.$value['id'].'">
                            '.$value['serienavn'].'
                        </label>
                    </div>
                </div>';
            }
        $html .='
        <hr>
        
        <div>Designer</div>
        <select name="designer">
        ';
        $sql = "SELECT * FROM designer";
        $arr = getData($sql, $conn);
        foreach($arr as $value){
            $html .= '
           <option class="dropdown-item" value="'.$value['id'].'">'.$value['designnavn'].'</option>';
        }
        
        $html .=' 
        </select>
        <hr>
        <div>Design-år</div>
        <input type="number" name="designAar" placeholder="Design-år">
       
        <hr>
        <div>Pris</div>
        <input type="number" name="pris" placeholder="Pris">
        
        <hr>
        <div>Produktfoto</div>
        <input type="file" multiple name="produktfoto[]" value="Produktfoto">
        <hr>
            <button type="submit" name="submitIndsaetMoebel" class="btn">Indsæt</button>
        </form>
        </div>
    </div>';
    return $html;