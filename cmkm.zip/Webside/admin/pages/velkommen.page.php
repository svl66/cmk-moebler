<?php
$_SESSION['user'] = 'admin';
$html = '
<h3 class="orangeFont">Velkommen til administrationssiden, <strong>'.$_SESSION['user'].'!</strong></h3>
<p>Du kan på denne side oprette, redigere og 
slette elementer tilhørende <strong>'.PROJECT_NAME.'</strong>';

return $html;