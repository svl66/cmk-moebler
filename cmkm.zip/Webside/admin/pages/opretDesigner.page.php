<?php
$html = '';
if($_POST){
    if(isset($_POST['submitNyDesigner'])){
        $designnavn = secInput($_POST['designer']);
        if( checkElement($designnavn)){
            $sql = "INSERT INTO `designer`(`designnavn`) VALUES ('$designnavn')";
            insertData($sql, $conn);
            $html .= '<p class="orangeFont">Du har indsat ny designer ('.$designnavn.') med succes!';
        }
    }
}
$html .= '
    <script>
        function tjekForm(){
            var str=document.forms.formDesigner;
            if(str.designer.value === ""){
                alert(\'Designer skal indholde et navn\');
                return false;
            }
        }
    </script>
    <div class="myFunitureSection">
        <h5 class="orangeFont">Opret ny designer</h5>
        <form action="" method="post" id="formDesigner" onsubmit="return tjekForm()">
            <input type="text" name="designer" id="designer">
            <br>
            <div class="marginTop5">
                <input type="submit" class="btn btn-white" name="submitNyDesigner" value="Tilføj">
            </div>
        </form>
    </div>';
return $html;