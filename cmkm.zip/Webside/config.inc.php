<?php
session_start();
date_default_timezone_set('Europe/Copenhagen');
error_reporting(E_ALL);         // E_ALL sættes til 0 når vi er færdige
ini_set('display_errors', 1);   // Denne linje fjernes når vi er færdige
define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', 'root');
define('DB_NAME', 'rts_cmkm');
define('PROJECT_NAME', 'CMK Møbler');
define('PROJECT_EMAIL_SALES', 'sales@cmkmobler.dk');
define('PROJECT_EMAIL_INFO', 'info@cmkmobler.dk');