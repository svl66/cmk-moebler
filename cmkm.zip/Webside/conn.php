<?php

$conn = mysqli_connect(HOST, USER, PASSWORD, DB_NAME);
mysqli_set_charset($conn, 'utf8');